<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\users;
use App\Models\course;
use Hash;
use Illuminate\Support\Facades\DB;
use App\Models\profile;
use App\Models\contact;
use App\Models\education;
use App\Models\ask;
use App\Models\job;
use App\Models\event;

class admin extends Controller
{
    //admin-home
    public function admin(){
        $yesCount = DB::table('asks')
        ->where('related', 'yes')
        ->distinct()
        ->count('userId');

        $noCount = DB::table('asks')
        ->where('related', 'no')
        ->distinct()
        ->count('userId');

        $noCountJob = DB::table('asks')
        ->where('job', 'no')
        ->distinct()
        ->count('userId');
        
        $yesCountJob = DB::table('asks')
        ->where('job', 'yes')
        ->distinct()
        ->count('userId');

        $courseCounts = profile::join('courses', 'profiles.userIdCourse', '=', 'courses.id')
        ->select('courses.course', DB::raw('COUNT(profiles.id) as count'))
        ->groupBy('courses.course')
        ->get()
        ->pluck('count', 'course')
        ->toArray();

        $event = event::count();
        return view('admin/admin-home', compact('yesCount', 'noCount', 'noCountJob', 'yesCountJob', 'courseCounts', 'event'));
    }

     //admin-home
     public function course(){
        $courses = course::all();
        return view('admin/admin-course', compact('courses'));
    }

    //admin-home
    public function eventAdmin(){
        $events = event::all();
        return view('admin/admin-eventAdmin', compact('events'));
    }

      //admin-home
    public function profile($courseId){
        $course = Course::find($courseId);
        $profiles = Profile::where('userIdCourse', $courseId)->get();
        return view('admin/admin-profile', compact('courseId', 'course', 'profiles'));
    }

    //admin-home ------------------------------
    public function personProfile($profileID){
        $profiles = Profile::where('userId', $profileID)->first();
        $contact = contact::where('userId', $profileID)->first();
        $education = education::where('userId', $profileID)->first();
        $ask = ask::where('userId', $profileID)->first();
        $jobs = job::where('userId', $profileID)->get();
        // dd($job);
        return view('admin/admin-personProfile', compact('profileID', 'profiles', 'contact', 'education', 'ask', 'jobs'));
        
    }

     //admin-home
     public function addCourse(){
        $courses = Course::where('status', 0)->get();
        return view('admin/admin-addCourse', compact('courses'));
    }

    //admin-home
    public function courseDelete($id){
        $courses = Course::find($id);
        if($courses) {
            $courses->status = 1;
            $courses->save();
            return back()->with('success', 'Course deleted.');
        } else {
             return back()->with('error', 'Delete error');
        }
    }

      //admin-home
    public function addUsers(){
        $users = users::where('role', 0)->get();
        return view('admin/admin-addUsers', compact('users'));
    }

    public function deleteUser($id){
        $users = users::find($id);
        if ($users) {
            $users->delete();
             return back()->with('success', 'Data has been deleted.');
        } else {
             return back()->with('error', 'Delete error');
        }
    }

    public function deleteEvent($id){
        $event = event::find($id);
        if ($event) {
            $event->delete();
             return back()->with('success', 'Data has been deleted.');
        } else {
             return back()->with('success', 'Delete error');
        }
    }

    public function deleteUpdate($id) {
        $event = event::find($id)->first();
        return view('admin/admin-deleteUpdate', compact('event'));
    }

    public function userList(){
        $users = users::where('role', 0)->get();
        return view('admin/admin-userList', compact('users'));
    }

    public function userUpdate($id){
        $users = users::find($id);
        return view('admin/admin-userUpdate', compact('id', 'users'));
    }

    public function courseList(){
        $courses = course::all();
        return view('admin/admin-courseList', compact('courses'));
    }

    public function courseUpdate($id){
        $course = course::find($id);
        return view('admin/admin-courseUpdate', compact('id', 'course'));
    }


    public function account(){
        $users = users::find(3);
        return view('admin/admin-account', compact('users'));
    }

    public function report(){
        $courseCounts = DB::table('courses')
        ->leftJoin('profiles', 'profiles.userIdCourse', '=', 'courses.id')
        ->leftJoin('asks', 'asks.userId', '=', 'profiles.userId')
        ->selectRaw('courses.course, 
                    SUM(CASE WHEN asks.related = "yes" THEN 1 ELSE 0 END) AS yes_related_count,
                    SUM(CASE WHEN asks.related = "no" THEN 1 ELSE 0 END) AS no_related_count')
        ->groupBy('courses.course')
        ->get();
        return view('admin/admin-report', compact('courseCounts'));
    }

    public function jobs(){
        $courseCounts = DB::table('courses')
        ->leftJoin('profiles', 'profiles.userIdCourse', '=', 'courses.id')
        ->leftJoin('asks', 'asks.userId', '=', 'profiles.userId')
        ->selectRaw('courses.course, 
                    SUM(CASE WHEN asks.job = "yes" THEN 1 ELSE 0 END) AS yes_count,
                    SUM(CASE WHEN asks.job = "no" THEN 1 ELSE 0 END) AS no_count')
        ->groupBy('courses.course')
        ->get();
        return view('admin/admin-jobs', compact('courseCounts'));
    }

    




    //admin-home
    public function batch($course){
        $courseId = Course::where('course', $course)->value('id');
        $coursename = Course::where('course', $course)->value('course');
        $uniqueYearGValues = DB::table('profiles')
        ->where('userIdCourse', $courseId)
        ->distinct()
        ->pluck('yearG');
        return view('admin/admin-batch', compact('courseId', 'uniqueYearGValues', 'coursename'));

    }

    //na baliktan ni hahahha kapoy edit
    public function yearBatch($year, $courseId) {
        $profiles = Profile::where('yearG', $courseId)
        ->where('userIdCourse',$year)
        ->get();
        $course = Course::find($year);
        return view('admin/admin-yearBatch', compact('profiles', 'year', 'courseId', 'course'));
    }


    //post function------------------------
    public function addUser(Request $request) {
        
        $request->validate([
            'username' => 'required',
            'pass' => 'required',
        ]);

        $users = new users();
        $users->username = $request->username;
        $users->password = Hash::make($request->pass);
        $users->role     = 0;
        $users->status   = 0;
        $users->save();
        return back()->with('success', 'Data has been saved.');
        
    }

    public function addCourses(Request $request) {
        $request->validate([
            'acronym' => 'required',
            'cname' => 'required',
        ]);

        $course = new course();
        $course->acronym = strtoupper($request->acronym);
        $course->course = strtoupper($request->cname);
        $course->status   = 0;
        $course->save();
        return back()->with('success', 'Data has been saved.');
    }

    public function updateCourse(Request $request) {
        $request->validate([
            'acronym' => 'required',
            'cname' => 'required',
        ]);
        $course = course::find($request->id);
        $course->acronym = strtoupper($request->acronym);
        $course->course = strtoupper($request->cname);
        $course->save();
        return back()->with('success', 'Data has been saved.');

    }

    public function updateUser(Request $request) { 
        $request->validate([
            'username' => 'required',
            'pass' => 'required',
        ]);
        $users = users::find($request->id);
        $users->username = $request->username;
        $users->password = Hash::make($request->pass);
        $users->save();
        return back()->with('success', 'Data has been saved.');

    }

    public function myAccount(Request $request) { 
        $request->validate([
            'username' => 'required',
            'pass' => 'required',
        ]);
        $users = users::find(3);
        $users->username = $request->username;
        $users->password = Hash::make($request->pass);
        $users->save();
        return back()->with('success', 'Data has been saved.');

    }


    // public function importData(Request $request)
    // {
    //     // Validate the uploaded file
    //     $request->validate([
    //         'csv_file' => 'required|file|mimes:csv,txt',
    //     ]);
    
    //     // Get the uploaded file
    //     $uploadedFile = $request->file('csv_file');
    
    //     // Generate a unique filename
    //     $filename = time() . '_' . $uploadedFile->getClientOriginalName();
    
    //     // Move the uploaded file to a directory within your application
    //     $destinationPath = public_path('uploads'); // Change this to your preferred storage location
    //     $uploadedFile->move($destinationPath, $filename);
    
    //     // Now, you can use the path to the uploaded file for further processing
    //     $csvFilePath = $destinationPath . '/' . $filename;
    
    //     // Parse and process the CSV data
    //     $csvData = file_get_contents($csvFilePath);
    //     $rows = explode(PHP_EOL, $csvData);
    
    //     foreach ($rows as $row) {
    //         $rowData = str_getcsv($row);
    //         // Process each row of data as needed
    //         // Example: Create a new record in the database
    //         if (count($rowData) < 3) {
    //             // Handle the case where the row doesn't have enough data
    //             // You can log an error, skip the row, or take appropriate action
    //             continue;
    //         }
    
    //         users::create([
    //             'username' => $rowData[0], // Adjust column names accordingly
    //             'password' =>  Hash::make($rowData[1]),
    //             'status' => $rowData[2],
    //             'role' => 0,
    //         ]);
    //     }
    
    //     // Optionally, you can redirect the user with a success message
    //     return back()->with('success', 'Data imported successfully.');
    // }


    public function importData(Request $request)
{
    // Validate the uploaded file
    $request->validate([
        'csv_file' => 'required|file|mimes:csv,txt',
    ]);

    // Get the uploaded file
    $uploadedFile = $request->file('csv_file');

    // Generate a unique filename
    $filename = time() . '_' . $uploadedFile->getClientOriginalName();

    // Move the uploaded file to a directory within your application
    $destinationPath = public_path('uploads'); // Change this to your preferred storage location
    $uploadedFile->move($destinationPath, $filename);

    // Now, you can use the path to the uploaded file for further processing
    $csvFilePath = $destinationPath . '/' . $filename;

    // Parse and process the CSV data
    $csvData = file_get_contents($csvFilePath);
    $rows = explode(PHP_EOL, $csvData);

    foreach ($rows as $row) {
        $rowData = str_getcsv($row);

        if (count($rowData) < 2) {
            // Handle the case where the row doesn't have enough data
            continue;
        }

        // Check if the username already exists
        $existingUser = Users::where('username', $rowData[0])->first();
        if ($existingUser) {
            // Handle the case where the username already exists
            // You can log an error, skip the row, or take appropriate action
            continue;
        }

        // Validate the unique constraint using Laravel validation rulesphp artisan serve
        $request->validate([
            'username' => 'unique:users,username',
        ]);

        // Create a new record in the database
        Users::create([
            'username' => $rowData[0],
            'password' => Hash::make($rowData[1]),
            'status' => 0,
            'role' => 0,
        ]);
    }

    // Optionally, you can redirect the user with a success message
    return back()->with('success', 'Data imported successfully.');
}



    public function eventPost (Request $request)  {

        $request->validate([
            'photo' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'started' => 'required',
            'end' => 'required',
            'desc' => 'required',
        ]);

        // dd($request->all());

        $event = new event();
        $event->started = $request->started;
        $event->end     = $request->end;
        $event->desc    = $request->desc;
        // $event->photo = $request->cname;
        $event->status  = 0;
     
     
    
        // Store the uploaded image in the 'public/photos' directory
        $imagePath = $request->file('photo')->store('public/photos');
    
        // Retrieve the user's profile based on the user's ID in the session
        // $profile = Profile::where('userId', session('users')->id)->first();
    
        // if ($profile !== null) {
            // Get the file name with extension from the full image path
        $imageNameWithExtension = pathinfo($imagePath, PATHINFO_BASENAME);
    
            // Update the 'photo' (or 'profile') field with the file name and extension
            // $profile->profile = $imageNameWithExtension;
        $event->photo = $imageNameWithExtension;
        $event->save();
    
            // Optionally, you can delete the old profile photo if needed
            // Storage::delete('public/photos/' . $profile->profile);
        return back()->with('success', 'Data has been saved.');
        // }

        
    }


    public function eventPostUpdate (Request $request)  {

        $request->validate([
            'photo' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
            'started' => 'required',
            'end' => 'required',
            'desc' => 'required',
        ]);

        // dd($request->all());

        $event = event::find($request->id);
        $event->started = $request->started;
        $event->end     = $request->end;
        $event->desc    = $request->desc;
        // $event->photo = $request->cname;
        $event->status  = 0;
     
     
    
        // Store the uploaded image in the 'public/photos' directory
        $imagePath = $request->file('photo')->store('public/photos');
    
        // Retrieve the user's profile based on the user's ID in the session
        // $profile = Profile::where('userId', session('users')->id)->first();
    
        // if ($profile !== null) {
            // Get the file name with extension from the full image path
        $imageNameWithExtension = pathinfo($imagePath, PATHINFO_BASENAME);
    
            // Update the 'photo' (or 'profile') field with the file name and extension
            // $profile->profile = $imageNameWithExtension;
        $event->photo = $imageNameWithExtension;
        $event->save();
    
            // Optionally, you can delete the old profile photo if needed
            // Storage::delete('public/photos/' . $profile->profile);
        return back()->with('success', 'Data has been saved.');
        // }

        
    }



    










}
