<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\login;
use App\Http\Controllers\user;
use App\Http\Controllers\admin;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::middleware(['user'])->group(function () {

    Route::get('user-home', [user::class, 'home'])->name('user-home');
    Route::get('user-basic', [user::class, 'basic'])->name('user-basic');
    Route::get('user-contact', [user::class, 'contact'])->name('user-contact');
    Route::get('user-profile', [user::class, 'profile'])->name('user-profile');
    Route::get('user-employment', [user::class, 'employment'])->name('user-employment');
    Route::get('user-ask', [user::class, 'ask'])->name('user-ask');
    Route::get('user-education', [user::class, 'education'])->name('user-education');
    Route::get('user-gradute', [user::class, 'gradute'])->name('user-gradute');
    Route::get('user-updatebasic', [user::class, 'updatebasic'])->name('user-updatebasic');
    Route::get('user-updatecontact', [user::class, 'updatecontact'])->name('user-updatecontact');
    Route::get('user-updateemployment/{answer}', [user::class, 'updateemployment'])->name('user-updateemployment');
    Route::get('user-deleteUpdateemployment/{answer}', [user::class, 'deleteUpdateemployment'])->name('user-deleteUpdateemployment');
    Route::get('user-listemployment', [user::class, 'listemployment'])->name('user-listemployment');
    Route::get('user-updateeducation', [user::class, 'updateeducation'])->name('user-updateeducation');
    Route::get('user-updateask', [user::class, 'updateask'])->name('user-updateask');
    Route::get('user-listgradute', [user::class, 'listgradute'])->name('user-listgradute');
    Route::get('user-updategradute', [user::class, 'updategradute'])->name('user-updategradute');
    Route::get('user-gcc', [user::class, 'gcc'])->name('user-gcc');
    Route::get('user-gccTwo', [user::class, 'gccTwo'])->name('user-gccTwo');
    Route::get('user-eventUser', [user::class, 'eventUser'])->name('user-eventUser');
    Route::get('user-batch', [user::class, 'batch'])->name('user-batch');
    Route::get('user-settings', [user::class, 'settings'])->name('user-settings');
   


    Route::post('user-addProfileBasic', [user::class, 'addProfileBasic'])->name('user-addProfileBasic');
    Route::post('user-updateAddProfileBasic', [user::class, 'updateAddProfileBasic'])->name('user-updateAddProfileBasic');
    Route::post('user-addBasic', [user::class, 'addBasic'])->name('user-addBasic');
    Route::post('user-addContact', [user::class, 'addContact'])->name('user-addContact');
    Route::post('user-addEducation', [user::class, 'addEducation'])->name('user-addEducation');
    Route::post('user-addAsk', [user::class, 'addAsk'])->name('user-addAsk');
    Route::post('user-addemploy', [user::class, 'addemploy'])->name('user-addemploy');
    Route::post('user-addUpdateemployment', [user::class, 'addUpdateemployment'])->name('user-addUpdateemployment');
    Route::post('user-uploadProfile', [user::class, 'uploadProfile'])->name('user-uploadProfile');
    
    Route::post('user-settingPost', [user::class, 'settingPost'])->name('user-settingPost');
    
});



Route::middleware(['admin'])->group(function () {

    Route::get('admin-home', [admin::class, 'admin'])->name('admin-home');
    Route::get('admin-addCourse', [admin::class, 'addCourse'])->name('admin-addCourse');
    Route::get('admin-addUsers', [admin::class, 'addUsers'])->name('admin-addUsers');
    Route::get('admin-course', [admin::class, 'course'])->name('admin-course');
    Route::get('admin-profile/{courseId}', [admin::class, 'profile'])->name('admin-profile');
    Route::get('admin-batch/{course}', [admin::class, 'batch'])->name('admin-batch');
    Route::get('admin-personProfile/{profileID}', [admin::class, 'personProfile'])->name('admin-personProfile');
    Route::get('admin-yearBatch/{year}/{courseId}', [admin::class, 'yearBatch'])->name('admin-yearBatch');
    Route::get('admin-userList', [admin::class, 'userList'])->name('admin-userList');
    Route::get('admin-userUpdate/{id}', [admin::class, 'userUpdate'])->name('admin-userUpdate');
    Route::get('admin-courseList', [admin::class, 'courseList'])->name('admin-courseList');
    Route::get('admin-account', [admin::class, 'account'])->name('admin-account');
    Route::get('admin-courseUpdate/{id}', [admin::class, 'courseUpdate'])->name('admin-courseUpdate');
    Route::get('admin-report', [admin::class, 'report'])->name('admin-report');
    Route::get('admin-jobs', [admin::class, 'jobs'])->name('admin-jobs');
    Route::get('admin-eventAdmin', [admin::class, 'eventAdmin'])->name('admin-eventAdmin');
    Route::get('admin-deleteUser/{id}', [admin::class, 'deleteUser'])->name('admin-deleteUser');
    Route::get('admin-deleteEvent/{id}', [admin::class, 'deleteEvent'])->name('admin-deleteEvent');
    Route::get('admin-Update/{id}', [admin::class, 'deleteUpdate'])->name('admin-Update');
    Route::get('admin-courseDelete/{id}', [admin::class, 'courseDelete'])->name('admin-courseDelete');




    Route::post('admin-addUser', [admin::class, 'addUser'])->name('admin-addUser');
    Route::post('admin-addCourses', [admin::class, 'addCourses'])->name('admin-addCourses');
    Route::post('admin-updateCourse', [admin::class, 'updateCourse'])->name('admin-updateCourse');
    Route::post('admin-updateUser', [admin::class, 'updateUser'])->name('admin-updateUser');
    Route::post('admin-myAccount', [admin::class, 'myAccount'])->name('admin-myAccount');
    Route::post('admin-eventPost', [admin::class, 'eventPost'])->name('admin-eventPost');
    Route::post('admin-eventPostUpdate', [admin::class, 'eventPostUpdate'])->name('admin-eventPostUpdate');
    
    Route::post('admin-importData', [admin::class, 'importData'])->name('admin-importData');


});

Route::get('/', [login::class, 'login'])->name('login');
Route::get('logout', [login::class, 'logout'])->name('logout');
Route::get('forget', [login::class, 'forget'])->name('forget');
Route::post('loginAuth', [login::class, 'loginAuth'])->name('loginAuth');
Route::post('sendPlainTextEmail', [login::class, 'sendPlainTextEmail'])->name('sendPlainTextEmail');