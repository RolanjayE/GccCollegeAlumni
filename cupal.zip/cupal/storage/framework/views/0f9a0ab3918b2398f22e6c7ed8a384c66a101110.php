<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Update</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-addCourse.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-event.css')); ?>">
</head>
<body>
    
    <div class="bg">

    </div>

    <div class="addContainer  mb-3">
        <div class="wrapper">
            <a href="<?php echo e(route('admin-eventAdmin')); ?>" style="float: right;" class=""><i class="fa-solid fa-x"></i></a>
            <div class="add">
                <p class="p6">Event Update</p>
                <div class="eventcon">
                    <div class="form-event">
                        <p class="p3 ml-4">Event</p>
                        
                        <?php if(session('success')): ?><div class="alert alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>
                        <form action="<?php echo e(route('admin-eventPostUpdate')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <label for="">Date started</label>
                            <input type="hidden" name="id" id="" value="<?php echo e($event->id); ?>" >
                            <input type="date" name="started" id="" value="<?php echo e($event->started); ?>" >
                            <span style="color: red"><?php $__errorArgs = ['started'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
                            <label for="">Date end</label>
                            <input type="date" name="end" id="" value="<?php echo e($event->end); ?>">
                            <span style="color: red"><?php $__errorArgs = ['end'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
                            <label for="">Description</label><br>
                            <textarea name="desc" id="" rows="10"><?php echo e($event->desc); ?></textarea>
                            <span style="color: red"><?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br> 
                            <input type="file" name="photo" id="photo" onchange="displayImage(this)" value="<?php echo e($event->photo); ?>">
                            <span style="color: red"><?php $__errorArgs = ['started'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span><br>
                            <button type="submit" class="btn btn-success btn-sm mt-2">Save</button>
                        </form>
                    </div>
                    <div class="eventImg">
                        <!-- <img id="selectedImage" src="<?php echo e(asset('image/imgg.jpeg')); ?>" alt=""> -->
                        <img id="selectedImage" src="<?php echo e(asset('storage/photos/' . $event->photo)); ?>" alt="Profile Photo">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function displayImage(input) {
            var fileInput = input;
            var selectedImage = document.getElementById('selectedImage');
            
            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    selectedImage.src = e.target.result;
                };

                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    </script>
</body>
</html><?php /**PATH C:\cupal\resources\views/admin/admin-deleteUpdate.blade.php ENDPATH**/ ?>