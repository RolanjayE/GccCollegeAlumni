<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Degree</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-list-graduate.css')); ?>">
</head>
<body>
    

    <div class="bg">

    </div>

    <div class="list-container">
        <div class="wrapper">
            <div class="list-header">
                <a class="btn btn-success" href="<?php echo e(route('user-home')); ?>">Home</a>
                <a style="float: right;" class="btn btn-primary" href="<?php echo e(route('user-listgradute')); ?>">Add degree</a>
            </div>
            <p class="p6">My degree</p>
            <div class="list">
                <p class="p4">School name</p>
                <p class="p7">n/a</p>
                <p class="p4">Course</p>
                <p class="p7">n/a</p>
                <p class="p4">Year graduated</p>
                <p class="p7">n/a</p>
                <a style="float: right;" class="btn btn-primary" href="<?php echo e(route('user-listgradute')); ?>">Update</a>
            </div>
        </div>
    </div>



</body>
</html><?php /**PATH C:\cupal\resources\views/user/user-listgradute.blade.php ENDPATH**/ ?>