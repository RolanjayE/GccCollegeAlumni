<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/admin-home.css')); ?>">
</head>
<body>
   

    <div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a style="background-color: white; color: black;" href="<?php echo e(route('admin-home')); ?>"><i class="fa-solid fa-gauge"></i> Main dashboard</a></li>
                <li><a href="<?php echo e(route('admin-addCourse')); ?>"><i class="fa-solid fa-folder"></i>  Add Course</a></li>
                <li><a href="<?php echo e(route('admin-addUsers')); ?>"><i class="fa-solid fa-user"></i> Add Users</a></li>
                <li><a href="<?php echo e(route('admin-eventAdmin')); ?>"><i class="fa-solid fa-calendar-days"></i> Add Event</a></li>
                <li><a href="<?php echo e(route('admin-course')); ?>"><i class="fa-regular fa-address-card"></i> Profiles</a></li>
                <li><a href="<?php echo e(route('admin-jobs')); ?>"><i class="fa-solid fa-chart-simple"></i> Jobs</a></li>
                <li><a href="<?php echo e(route('admin-report')); ?>"><i class="fa-solid fa-chart-simple"></i> Report</a></li>
                <li><a href="<?php echo e(route('admin-account')); ?>"><i class="fa-solid fa-gears"></i> Settings</a></li>
                <li><a href="<?php echo e(route('logout')); ?>"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Dashboard</p>
                <div class="board-con">
                    <?php $__currentLoopData = $courseCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="adminBoard">
                            <p class="p6"><?php echo e($course); ?></p>
                            <p style"" class="p1 heah"><?php echo e($count); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <p class="p3 mt-3">Event</p>
                <div class="board-con">
                    <div class="adminBoard">
                        <p class="p6">Total post</p>
                        <p style"" class="p1 heah"><?php echo e($event); ?></p>
                    </div>
                </div>
            </div>


        </div>
    </div>





</body>
</html><?php /**PATH C:\cupal\resources\views/admin/admin-home.blade.php ENDPATH**/ ?>