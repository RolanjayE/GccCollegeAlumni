<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('user/user-batch.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Batch</title>
</head>
<body>


    <div class="allb">
        <div class="batch">
           <div class="asdasd">
                <a href="<?php echo e(route('user-home')); ?>"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                <h1 class="h1">Welcome <?php echo e($profile->firstname); ?> <br> <span>Find Your Batchmates</span></h1>
                <input type="search" id="nameSearch" placeholder="Search name">
           </div>
        </div>
        <div class="batchTwo">
            
            <div class="box-wrapper">
                
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($course->firstname != "n/a"): ?>
                        <div class="boxs">
                            <?php if($course->profile !== "n/a"): ?>
                                <img class="img2" src="<?php echo e(asset('storage/photos/' . $course->profile)); ?>" alt="Profile Photo">
                            <?php else: ?> 
                                <img class="img2" src="<?php echo e(asset('image/banner.jpg')); ?>" alt=""> 
                            <?php endif; ?>
                            <div class="namesCon">
                                <p><?php echo e($course->firstname); ?> <?php echo e($course->lastname); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>

    <script>
        // Add event listener to the search input
        document.getElementById('nameSearch').addEventListener('input', function() {
            // Retrieve the search input value
            var searchValue = this.value.toLowerCase();

            // Loop through the names and show/hide based on the search input
            var names = document.querySelectorAll('.namesCon p');
            names.forEach(function(name) {
                var nameText = name.textContent.toLowerCase();
                var box = name.closest('.boxs');

                if (nameText.includes(searchValue)) {
                    box.style.display = 'flex';
                } else {
                    box.style.display = 'none';
                }
            });
        });
    </script>


    
</body>
</html><?php /**PATH C:\cupal\resources\views/user/user-batch.blade.php ENDPATH**/ ?>