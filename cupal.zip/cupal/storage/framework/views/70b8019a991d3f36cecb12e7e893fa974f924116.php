<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCC2</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-basic.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-batch.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-gcc.css')); ?>">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                
                <a href="<?php echo e(route('user-home')); ?>"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <p class="p6">I studied at Gingoog City Colleges and graduated with ?</p>
                <p class="haha">Select Here:</p>
                <span style="color: red">
                            <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span><br>
                <div class="con">
                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <div class="course-con" onclick="selectDiv(this)">
                            <p style="display: none" class="p1"><?php echo e($course->id); ?></p>
                            <p class="p1"><?php echo e($course->acronym); ?></p>
                            <!-- <p class="p4"> <?php echo e($course->course); ?></p> -->
                       </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="con2">
                    <form action="<?php echo e(route('user-updateAddProfileBasic')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <label for="">Year graduated</label>
                        <!-- <input placeholder="year graduated 2023" name="year">  -->
                        <select name="year" id="">
                            <option value="2023">-- Select --</option>
                            <option value="2023">2023</option>
                            <option value="2022">2022</option>
                            <option value="2021">2021</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                        </select>
                        <input type="hidden" id="selected-value" placeholder="Selected Value" name="courseID">
                        <span style="color: red">
                            <?php $__errorArgs = ['courseID'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </span><br>
                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save information</button>  
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    function selectDiv(selectedDiv) {
        var courseContainers = document.querySelectorAll(".course-con");

        courseContainers.forEach(function(container) {
            container.style.backgroundColor = ""; // Reset background color for all divs
        });

        selectedDiv.style.backgroundColor = "green"; // Change background color of the selected div

        var selectedText = selectedDiv.querySelector(".p1").textContent;
        document.getElementById("selected-value").value = selectedText;
    }
</script>

    
</body>
</html><?php /**PATH C:\cupal\resources\views/user/user-gcc2.blade.php ENDPATH**/ ?>