<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employment</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-list-graduate.css')); ?>">
</head>
<body>
    

    <div class="bg">

    </div>

    <div class="list-container">
        <div class="wrapper">
            <div class="list-header">
                <a class="btn btn-success btn-sm" href="<?php echo e(route('user-home')); ?>">Home</a>
                <a style="float: right;" class="btn btn-primary btn-sm" href="<?php echo e(route('user-employment')); ?>">Add Jobs</a>
            </div>
            <p class="p6">My Jobs</p>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                    <table id="example" class="table table-striped mt-2" style="width:100%">
                        <thead>
                            <tr>
                                <th>Company Name</th>
                                <th>Job Title</th>
                                <th>Position</th>
                                <th>Operation</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($job->company); ?></td>
                                    <td><?php echo e($job->title); ?></td>
                                    <td><?php echo e($job->position); ?></td>
                                    <td>
                                        <a style="float: right;" class="btn btn-primary btn-sm" href="<?php echo e(route('user-updateemployment', ['answer' => $job->id ])); ?>">Update</a>
                                        <a style="float: right; margin-right: 5px;" class="btn btn-danger btn-sm" href="<?php echo e(route('user-deleteUpdateemployment', ['answer' => $job->id ])); ?>">delete</a>
                                   </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Company Name</th>
                                <th>Job Title</th>
                                <th>Position</th>
                                <th>Operation</th>
                            </tr>
                        </tfoot>
                    </table>


        </div>
    </div>

    <script>
        new DataTable('#example');
    </script>

</body>
</html><?php /**PATH C:\cupal\resources\views/user/user-listemployment.blade.php ENDPATH**/ ?>