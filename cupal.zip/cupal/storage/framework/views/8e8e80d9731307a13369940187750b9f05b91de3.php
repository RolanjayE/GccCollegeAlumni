<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update education</title>
    <?php if (isset($component)) { $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda = $component; } ?>
<?php $component = App\View\Components\GlobalHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('globalHeader'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GlobalHeader::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda)): ?>
<?php $component = $__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda; ?>
<?php unset($__componentOriginalf35104bc982ab6be8e034d1b9dfac6234ae0ffda); ?>
<?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('global/global.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-basic.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-batch.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('user/user-educ.css')); ?>">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="<?php echo e(route('user-home')); ?>"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                <p class="p6">Update education information</p>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="con">
                    <form action="<?php echo e(route('user-addEducation')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <div class="flex">
                            <div class="f-box">
                                <label for="">Elementary education</label>
                                <input type="text" placeholder="" value="<?php echo e($education->elem); ?>" name="elem">
                                <span style="color: red">
                                        <?php $__errorArgs = ['elem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span><br>
                            </div>
                            <div class="f-box">
                                <label for="">Gradute year</label>
                                <input type="text" placeholder="" value="<?php echo e($education->yearElem); ?>" name="yearElem">
                                <span style="color: red">
                                        <?php $__errorArgs = ['yearElem'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span><br>
                            </div>
                        </div>

                        <div class="flex">
                            <div class="f-box">
                                <label for="">High School education</label>
                                <input type="text" placeholder="" value="<?php echo e($education->highSchool); ?>" name="highSchool">
                                <span style="color: red">
                                        <?php $__errorArgs = ['highSchool'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span><br>
                            </div>
                            <div class="f-box">
                                <label for="">Gradute year</label>
                                <input type="text" placeholder="" value="<?php echo e($education->yearhighSchool); ?>" name="yearhighSchool">
                                <span style="color: red">
                                        <?php $__errorArgs = ['yearhighSchool'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span><br>
                            </div>
                        </div>

                        <div class="flex">
                            <div class="f-box">
                                <label for="">Senior high School education</label>
                                <input type="text" placeholder="" value="<?php echo e($education->senior); ?>" name="senior">
                                <span style="color: red">
                                        <?php $__errorArgs = ['senior'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span><br>
                            </div>
                            <div class="f-box">
                                <label for="">Gradute year</label>
                                <input type="text" placeholder="" value="<?php echo e($education->YearSenior); ?>" name="YearSenior">
                                <span style="color: red">
                                        <?php $__errorArgs = ['YearSenior'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </span><br>
                            </div>
                        </div>

                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save information</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html><?php /**PATH C:\cupal\resources\views/user/user-updateeducation.blade.php ENDPATH**/ ?>