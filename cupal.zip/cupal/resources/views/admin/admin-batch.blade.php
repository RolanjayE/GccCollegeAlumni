<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bacth</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-home.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-profile.css') }}">

</head>
<body>


<div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a href="{{ route('admin-home') }}">Main dashboard</a></li>
                <li><a  href="{{ route('admin-addCourse') }}"><i class="fa-solid fa-folder"></i> Add Course</a></li>
                <li><a  href="{{ route('admin-addUsers') }}">Add Users</a></li>
                <li><a href="{{ route('admin-eventAdmin') }}">Add Event</a></li>
                <li><a style="background-color: white; color: black;" href="{{ route('admin-course') }}">Profiles</a></li>
                <li><a href="{{ route('admin-jobs') }}">Jobs</a></li>
                <li><a href="{{ route('admin-report') }}">Report</a></li>
                <li><a href="{{ route('admin-account') }}">Settings</a></li>
                <li><a href="{{ route('logout') }}">Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Profiles</p>
                <p class="p6">{{ $coursename }}</p>
                <div class="wrapper1 choy">
                    @foreach ($uniqueYearGValues as $uniqueYearGValue)
                        <button><a href="{{ route('admin-yearBatch', ['year' => $courseId, 'courseId' => $uniqueYearGValue] )}}">{{ $uniqueYearGValue }}</a></button>
                    @endforeach
                </div>
     
            </div>


        </div>
    </div>

</body>
</html>