<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Event</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-addCourse.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-home.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-event.css') }}">


    
  
</head>
<body>

    <div class="mainADmin mb-4">
        <div class="sideLeft">
            <ul>
                <li><a href="{{ route('admin-home') }}"><i class="fa-solid fa-gauge"></i> Main dashboard</a></li>
                <li><a href="{{ route('admin-addCourse') }}"><i class="fa-solid fa-folder"></i>  Add Course</a></li>
                <li><a href="{{ route('admin-addUsers') }}"><i class="fa-solid fa-user"></i> Add Users</a></li>
                <li><a style="background-color: white; color: black;" href="{{ route('admin-eventAdmin') }}"><i class="fa-solid fa-calendar-days"></i> Add Event</a></li>
                <li><a href="{{ route('admin-course') }}"><i class="fa-regular fa-address-card"></i> Profiles</a></li>
                <li><a href="{{ route('admin-jobs') }}"><i class="fa-solid fa-chart-simple"></i> Jobs</a></li>
                <li><a href="{{ route('admin-report') }}"><i class="fa-solid fa-chart-simple"></i> Report</a></li>
                <li><a href="{{ route('admin-account') }}"><i class="fa-solid fa-gears"></i> Settings</a></li>
                <li><a href="{{ route('logout') }}"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
           
           <div class="eventcon">
                <div class="form-event">
                    <p class="p3 ml-4">Event</p>
                    
                    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                    <form action="{{ route('admin-eventPost') }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <label for="">Date started</label>
                        <input type="date" name="started" id="">
                        <span style="color: red">@error('started'){{ $message }}@enderror</span><br>
                        <label for="">Date end</label>
                        <input type="date" name="end" id="">
                        <span style="color: red">@error('end'){{ $message }}@enderror</span><br>
                        <label for="">Description</label><br>
                        <textarea name="desc" id="" rows="10"></textarea>
                        <span style="color: red">@error('desc'){{ $message }}@enderror</span><br> 
                        <input type="file" name="photo" id="photo" onchange="displayImage(this)">
                        <span style="color: red">@error('started'){{ $message }}@enderror</span><br>
                        <button type="submit" class="btn btn-success btn-sm mt-2">Save</button>
                    </form>
                </div>
                <div class="eventImg">
                    <img id="selectedImage" src="{{ asset('image/imgg.jpeg') }}" alt="">
                </div>
           </div>




            <div class="allDataHere">
                
                
                <div class="table mt-4">
                    <table id="example" class="table table-striped mt-2" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Operation</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($events as $event)
                                    <tr>
                                        <td>{{ $event->desc }}</td>
                                        <td>
                                            <a href="{{ route('admin-Update', ['id' => $event->id ]) }}" class="btn btn-success btn-sm">Update</a>
                                            <a href="{{ route('admin-deleteEvent', ['id' => $event->id ]) }}" class="btn btn-danger btn-sm mt-1" >Delete</a>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        <tfoot>
                            <tr>
                                <th>Description</th>
                                <th>Operation</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>

            </div>

            

        </div>
    </div>
    
    <script>
        new DataTable('#example');
    </script>


    <script>
        function displayImage(input) {
            var fileInput = input;
            var selectedImage = document.getElementById('selectedImage');
            
            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    selectedImage.src = e.target.result;
                };

                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    </script>


</body>
</html>