<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course list</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-addCourse.css') }}">
</head>
<body>

<div class="bg">

    </div>

    <div class="addContainer">
        <div class="wrapper">
            <a href="{{ route('admin-home') }}" class="btn btn-success mb-4">Home</a>
            <div class="add">
                <input type="search" placeholder="Search" class="mb-2">
               <table>
                    <tr>
                        <th>Name</th>
                        <th>Acronym</th>
                        <th>Operation</th>
                    </tr>
                    @foreach ($courses as $course)
                    <tr>
                        <td>{{ $course->course }}</td>
                        <td>{{ $course->acronym }}</td>
                        <td style="display: flex; gap:10px">
                            <a href="" style="font-size: 11px" class="btn btn-danger">Delete </a>
                            <a href="{{ route('admin-courseUpdate', ['id' => $course->id]) }}" style="font-size: 11px" class="btn btn-success">Update </a>
                        </td>
                    </tr>
                    @endforeach
               </table>
            </div>
        </div>
    </div>
    
</body>
</html>