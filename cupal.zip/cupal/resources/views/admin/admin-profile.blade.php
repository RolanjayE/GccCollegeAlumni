<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-home.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-profile.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-home.css') }}">
</head>
<body>

    <div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a style="background-color: white; color: black;" href="{{ route('admin-home') }}"><i class="fa-solid fa-gauge"></i> Main dashboard</a></li>
                <li><a href="{{ route('admin-addCourse') }}"><i class="fa-solid fa-folder"></i>  Add Course</a></li>
                <li><a href="{{ route('admin-addUsers') }}"><i class="fa-solid fa-user"></i> Add Users</a></li>
                <li><a href="{{ route('admin-eventAdmin') }}"><i class="fa-solid fa-calendar-days"></i> Add Event</a></li>
                <li><a style="background-color: white; color: black;" href="{{ route('admin-course') }}"><i class="fa-regular fa-address-card"></i> Profiles</a></li>
                <li><a href="{{ route('admin-jobs') }}"><i class="fa-solid fa-chart-simple"></i> Jobs</a></li>
                <li><a href="{{ route('admin-report') }}"><i class="fa-solid fa-chart-simple"></i> Report</a></li>
                <li><a href="{{ route('admin-account') }}"><i class="fa-solid fa-gears"></i> Settings</a></li>
                <li><a href="{{ route('logout') }}">Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Profiles</p>
                <a class="btn btn-primary btn-sm" href="{{ route('admin-batch', ['course' => $course->course]) }}">Batch Year</a>
                <p class="p6">{{ $course->course }}</p>
                <input type="search" name="search" id="profileSearch" placeholder="Search name">
                <div class="profile-con" id="profileContainer">
                    @foreach ($profiles as $profile)
                        
                        <div class="profile">
                            @if($profile->profile !== "n/a")
                                <img style="width: 95px; height: 95px;" src="{{ asset('storage/photos/' . $profile->profile) }}" alt="Profile Photo">
                            @else 
                                <img style="width: 95px; height: 95px;" src="{{ asset('image/banner.jpg') }}" alt=""> 
                            @endif
                            <div class="infohe">
                                <p class="p7">{{ $profile->firstname }} {{ $profile->lastname }} {{ $profile->middlename }}</p>
                                <p class="p7">{{ $course->acronym  }}</p>
                                <a class="btn btn-success btn-sm mt-1" href="{{ route('admin-personProfile', ['profileID' => $profile->userId]) }}">View profile</a>
                            </div>
                        </div>
            
                    @endforeach
                </div>
            </div>


        </div>
    </div>



    <script>
    document.addEventListener('DOMContentLoaded', function () {
        var profileContainer = document.getElementById('profileContainer');
        var profileSearch = document.getElementById('profileSearch');

        profileSearch.addEventListener('input', function () {
            var searchTerm = profileSearch.value.toLowerCase();

            Array.from(profileContainer.getElementsByClassName('profile')).forEach(function (profile) {
                var profileName = profile.querySelector('.p7').textContent.toLowerCase();

                if (profileName.includes(searchTerm)) {
                    profile.style.display = 'flex';
                } else {
                    profile.style.display = 'none';
                }
            });
        });
    });
</script>


</body>
</html>