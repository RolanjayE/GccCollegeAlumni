<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Update</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-addCourse.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <link rel="stylesheet" href="{{ asset('admin/admin-event.css') }}">
</head>
<body>
    
    <div class="bg">

    </div>

    <div class="addContainer  mb-3">
        <div class="wrapper">
            <a href="{{ route('admin-eventAdmin') }}" style="float: right;" class=""><i class="fa-solid fa-x"></i></a>
            <div class="add">
                <p class="p6">Event Update</p>
                <div class="eventcon">
                    <div class="form-event">
                        <p class="p3 ml-4">Event</p>
                        
                        @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>@endif
                        <form action="{{ route('admin-eventPostUpdate') }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <label for="">Date started</label>
                            <input type="hidden" name="id" id="" value="{{ $event->id }}" >
                            <input type="date" name="started" id="" value="{{ $event->started }}" >
                            <span style="color: red">@error('started'){{ $message }}@enderror</span><br>
                            <label for="">Date end</label>
                            <input type="date" name="end" id="" value="{{ $event->end }}">
                            <span style="color: red">@error('end'){{ $message }}@enderror</span><br>
                            <label for="">Description</label><br>
                            <textarea name="desc" id="" rows="10">{{ $event->desc }}</textarea>
                            <span style="color: red">@error('desc'){{ $message }}@enderror</span><br> 
                            <input type="file" name="photo" id="photo" onchange="displayImage(this)" value="{{ $event->photo }}">
                            <span style="color: red">@error('started'){{ $message }}@enderror</span><br>
                            <button type="submit" class="btn btn-success btn-sm mt-2">Save</button>
                        </form>
                    </div>
                    <div class="eventImg">
                        <!-- <img id="selectedImage" src="{{ asset('image/imgg.jpeg') }}" alt=""> -->
                        <img id="selectedImage" src="{{ asset('storage/photos/' . $event->photo) }}" alt="Profile Photo">
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function displayImage(input) {
            var fileInput = input;
            var selectedImage = document.getElementById('selectedImage');
            
            if (fileInput.files && fileInput.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    selectedImage.src = e.target.result;
                };

                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    </script>
</body>
</html>