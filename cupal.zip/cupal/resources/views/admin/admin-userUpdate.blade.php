<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users Update</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-addCourse.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    
    <div class="bg">

    </div>

    <div class="addContainer">
        <div class="wrapper">
            <a href="{{ route('admin-addUsers') }}" style="float: right;" class=""><i class="fa-solid fa-x"></i></a>
            <div class="add">
                <p class="p6">Update Users</p>
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <form action="{{ route('admin-updateUser') }}" method="post">
                    @csrf
                    <label for="">Schoold ID {{ $id }}</label> 
                    <input type="hidden" placeholder="" name="id" value="{{ $users->id }}">
                    <input type="text" placeholder="" name="username" value="{{ $users->username }}">
                    <span style="color: red">
                                @error('username')
                                    {{ $message }}
                                @enderror
                        </span><br>
                    <label for="">Password</label>
                    <input type="text" placeholder="" name="pass">
                    <span style="color: red">
                                @error('pass')
                                    {{ $message }}
                                @enderror
                        </span><br>
                    <button type="submit" class="mt-3 btn btn-success btn-sm">Save</button>
                </form>
            </div>
        </div>
    </div>

</body>
</html>