<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Course</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-addCourse.css') }}">
    <link rel="stylesheet" href="{{ asset('admin/admin-home.css') }}">
</head>
<body>

    <div class="mainADmin">
        <div class="sideLeft">
            
            <ul>
                <li><a href="{{ route('admin-home') }}"><i class="fa-solid fa-gauge"></i> Main dashboard</a></li>
                <li><a style="background-color: white; color: black;" href="{{ route('admin-addCourse') }}"><i class="fa-solid fa-folder"></i>  Add Course</a></li>
                <li><a href="{{ route('admin-addUsers') }}"><i class="fa-solid fa-user"></i> Add Users</a></li>
                <li><a href="{{ route('admin-eventAdmin') }}"><i class="fa-solid fa-calendar-days"></i> Add Event</a></li>
                <li><a href="{{ route('admin-course') }}"><i class="fa-regular fa-address-card"></i> Profiles</a></li>
                <li><a href="{{ route('admin-jobs') }}"><i class="fa-solid fa-chart-simple"></i> Jobs</a></li>
                <li><a href="{{ route('admin-report') }}"><i class="fa-solid fa-chart-simple"></i> Report</a></li>
                <li><a href="{{ route('admin-account') }}"><i class="fa-solid fa-gears"></i> Settings</a></li>
                <li><a href="{{ route('logout') }}"><i class="fa-solid fa-right-from-bracket"></i> Logout</a></li>
            </ul>
        </div>
        <div class="sideRight">
            <div class="adminHeader">
                <i class="menu1 fa-solid fa-bars mt-4"></i>
            </div>

            <div class="allDataHere">
                <p class="p3 mb-4">Course</p>
                <div class="formConta">
                    @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>
                    @endif
                    <form action="{{ route('admin-addCourses') }}" method="post">
                    @csrf
                        <label for="">Acronym</label>
                        <input style="text-transform: uppercase;" type="text" placeholder="" name="acronym">
                        <span style="color: red">@error('acronym'){{ $message }}@enderror</span><br>
                        <label for="">Course name</label>
                        <input style="text-transform: uppercase;" type="text" placeholder="" name="cname">
                        <span style="color: red">@error('cname'){{ $message }}@enderror</span><br>
                        <button type="submit" class="mt-3 btn btn-success btn-sm">Save</button>
                    </form>
                </div>
                <div class="table mt-4">

                    <table id="example" class="table table-striped mt-2" style="width:100%">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Acronym</th>
                                <th>Operation</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($courses as $course)
                                <tr>
                                    <td>{{ $course->course }}</td>
                                    <td>{{ $course->acronym }}</td>
                                    <td>
                                        <a href="{{ route('admin-courseDelete', ['id' => $course->id]) }}" style="font-size: 11px" class="btn btn-danger btn-sm">Delete </a>
                                        <a href="{{ route('admin-courseUpdate', ['id' => $course->id]) }}" style="font-size: 11px" class="btn btn-success btn-sm">Update </a>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Acronym</th>
                                <th>Operation</th>
                            </tr>
                        </tfoot>
                    </table>

                </div>
            </div>


        </div>
    </div>

    <script>
        new DataTable('#example');
    </script>


</body>
</html>