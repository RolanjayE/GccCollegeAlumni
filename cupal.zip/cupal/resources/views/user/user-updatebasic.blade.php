<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update Basic</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-batch.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="{{ route('user-home') }}"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <p class="p6">Update basic information</p>
                <div class="con">
                    <form action="{{ route('user-addBasic') }}" method="post">

                        @csrf
                        <label for="">First name</label>
                        <input type="text" placeholder="Ex. Juan" name="firstname" value="{{ $profile->firstname }}">
                        <span style="color: red">
                            @error('firstname')
                                {{ $message }}
                            @enderror
                        </span><br>
                        <label for="">Middle name</label>
                        <input type="text" placeholder="Ex. Gwapo" name="lastname" value="{{ $profile->lastname }}">
                        <span style="color: red">
                            @error('lastname')
                                {{ $message }}
                            @enderror
                        </span><br>
                        <label for="">Last name</label>
                        <input type="text" placeholder="Ex. Koh" name="middlename" value="{{ $profile->middlename }}">
                        <span style="color: red">
                            @error('middlename')
                                {{ $message }}
                            @enderror
                        </span><br>
                        

                        <div class="flex">
                            <div class="f-box">
                                <label for="">Gender</label>
                                <select name="gender" id="">
                                    <option value="{{ $profile->gender }}">{{ $profile->gender }}</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                                <span style="color: red">
                                    @error('gender')
                                        {{ $message }}
                                    @enderror
                                </span><br>
                            </div>
                            <div class="f-box">
                                <label for="">Status</label>
                                <select name="stats" id="">
                                    <option value="{{ $profile->stats }}">{{ $profile->stats }}</option>
                                    <option value="single">Single</option>
                                    <option value="married">Married</option>
                                </select>
                                <span style="color: red">
                                    @error('stats')
                                        {{ $message }}
                                    @enderror
                                </span><br>
                            </div>
                        </div>

                        <label for="">Birth</label>
                        <input type="date" placeholder="Koh" name="birth" value="{{ $profile->birth }}">
                        <span style="color: red">
                                    @error('birth')
                                        {{ $message }}
                                    @enderror
                                </span><br>

                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save information</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>