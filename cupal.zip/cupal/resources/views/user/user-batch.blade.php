<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('user/user-batch.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Batch</title>
</head>
<body>


    <div class="allb">
        <div class="batch">
           <div class="asdasd">
                <a href="{{ route('user-home') }}"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                <h1 class="h1">Welcome {{ $profile->firstname }} <br> <span>Find Your Batchmates</span></h1>
                <input type="search" id="nameSearch" placeholder="Search name">
           </div>
        </div>
        <div class="batchTwo">
            
            <div class="box-wrapper">
                
                @foreach ($courses as $course)
                    @if ($course->firstname != "n/a")
                        <div class="boxs">
                            @if($course->profile !== "n/a")
                                <img class="img2" src="{{ asset('storage/photos/' . $course->profile) }}" alt="Profile Photo">
                            @else 
                                <img class="img2" src="{{ asset('image/banner.jpg') }}" alt=""> 
                            @endif
                            <div class="namesCon">
                                <p>{{ $course->firstname }} {{ $course->lastname }}</p>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>

        </div>
    </div>

    <script>
        // Add event listener to the search input
        document.getElementById('nameSearch').addEventListener('input', function() {
            // Retrieve the search input value
            var searchValue = this.value.toLowerCase();

            // Loop through the names and show/hide based on the search input
            var names = document.querySelectorAll('.namesCon p');
            names.forEach(function(name) {
                var nameText = name.textContent.toLowerCase();
                var box = name.closest('.boxs');

                if (nameText.includes(searchValue)) {
                    box.style.display = 'flex';
                } else {
                    box.style.display = 'none';
                }
            });
        });
    </script>


    
</body>
</html>