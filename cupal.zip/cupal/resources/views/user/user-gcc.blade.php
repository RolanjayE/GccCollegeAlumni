<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCC</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-gcc.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <p class="p6">I studied at Gingoog City Colleges and graduated with ?</p>
                <p class="haha">Select Here:</p>
                <span style="color: red">
                        @error('year')
                            {{ $message }}
                        @enderror
                </span><br>
            
                <div class="con2">
                    <form action="{{ route('user-addProfileBasic') }}" method="post">
                        @csrf
                        <label for="">My Course</label>
                    
                        <select class="mt-2" name="courseID" id="">
                            <option value="">-- Select --</option>
                        @foreach($courses as $course)
                                <option value="{{ $course->id }}">{{ $course->acronym }}</option>
                        @endforeach
                        </select>
                        <label for="">Year graduated</label>
                        <select class="mt-4" name="year" id="">
                            <option value="">-- Select --</option>
                            <option value="2023">2023</option>
                            <option value="2022">2022</option>
                            <option value="2021">2021</option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                        </select>
                        
                        
                        <span style="color: red">
                            @error('courseID')
                                {{ $message }}
                            @enderror
                    </span><br>
                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success">Save information</button>  
                    </form>
                </div>
            </div>
        </div>
    </div>



    
</body>
</html>