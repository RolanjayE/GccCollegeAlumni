<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Degree</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-list-graduate.css') }}">
</head>
<body>
    

    <div class="bg">

    </div>

    <div class="list-container">
        <div class="wrapper">
            <div class="list-header">
                <a class="btn btn-success btn-sm" href="{{ route('user-home') }}">Home</a>
                <a style="float: right;" class="btn btn-primary btn-sm" href="{{ route('user-listgradute') }}">Add degree</a>
            </div>
            <p class="p6">My degree</p>
            <div class="list">
                <p class="p4">School name</p>
                <p class="p7">n/a</p>
                <p class="p4">Course</p>
                <p class="p7">n/a</p>
                <p class="p4">Year graduated</p>
                <p class="p7">n/a</p>
                <a style="float: right;" class="btn btn-primary btn-sm" href="{{ route('user-listgradute') }}">Update</a>
            </div>
        </div>
    </div>



</body>
</html>