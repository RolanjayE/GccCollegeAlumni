<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-batch.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-ask.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="{{ route('user-home') }}"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                
                @if(session('success'))<div class="alert alert-success">{{ session('success') }}</div>
                    @endif
                <div class="ask">
                    <form action="{{ route('user-settingPost') }}" method="post">
                    @csrf
                        <label for="">Username</label>
                        <input type="text" name="username">
                        <span style="color: red">@error('username'){{ $message }}@enderror</span><br>
                        <label for="">Password</label>
                        <input type="password" name="password">
                        <span style="color: red">@error('password'){{ $message }}@enderror</span><br>
                        <label for="">Repeat Password</label>
                        <input type="password" name="repeatPassword">
                        <span style="color: red">@error('repeatPassword'){{ $message }}@enderror</span><br>
                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save</button>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
    

</body>
</html>