<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ask</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-batch.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-ask.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="{{ route('user-home') }}"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                
                <div class="ask">
                    <form action="{{ route('user-addAsk') }}" method="post">
                    @csrf
                        <label for="">Do you have a job</label>
                        <input type="text" placeholder="[yes or no]" name="job">
                        <span style="color: red">
                                    @error('job')
                                        {{ $message }}
                                    @enderror
                                </span><br>
                        <label for="">Is your job related to the course you graduated in gingoog city colleges</label>
                        <input type="text" placeholder="[yes or no]" name="related">
                        <span style="color: red">
                                    @error('related')
                                        {{ $message }}
                                    @enderror
                                </span><br>
                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save information</button>
                    </form>
                </div>
                
            </div>
        </div>
    </div>
    
</body>
</html>