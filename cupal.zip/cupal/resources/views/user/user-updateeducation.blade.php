<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update education</title>
    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-basic.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-batch.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-educ.css') }}">
</head>
<body>

    <div class="bg">
                
    </div>

    <div class="container-all">
        <div class="wrapper">
            <div class="form-con">
                <a href="{{ route('user-home') }}"><i class="fa-regular fa-circle-xmark hehahe"></i></a>
                <p class="p6">Update education information</p>
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <div class="con">
                    <form action="{{ route('user-addEducation') }}" method="post">
                    @csrf
                        <div class="flex">
                            <div class="f-box">
                                <label for="">Elementary education</label>
                                <input type="text" placeholder="" value="{{ $education->elem }}" name="elem">
                                <span style="color: red">
                                        @error('elem')
                                            {{ $message }}
                                        @enderror
                                </span><br>
                            </div>
                            <div class="f-box">
                                <label for="">Gradute year</label>
                                <input type="text" placeholder="" value="{{ $education->yearElem }}" name="yearElem">
                                <span style="color: red">
                                        @error('yearElem')
                                            {{ $message }}
                                        @enderror
                                </span><br>
                            </div>
                        </div>

                        <div class="flex">
                            <div class="f-box">
                                <label for="">High School education</label>
                                <input type="text" placeholder="" value="{{ $education->highSchool }}" name="highSchool">
                                <span style="color: red">
                                        @error('highSchool')
                                            {{ $message }}
                                        @enderror
                                </span><br>
                            </div>
                            <div class="f-box">
                                <label for="">Gradute year</label>
                                <input type="text" placeholder="" value="{{ $education->yearhighSchool }}" name="yearhighSchool">
                                <span style="color: red">
                                        @error('yearhighSchool')
                                            {{ $message }}
                                        @enderror
                                </span><br>
                            </div>
                        </div>

                        <div class="flex">
                            <div class="f-box">
                                <label for="">Senior high School education</label>
                                <input type="text" placeholder="" value="{{ $education->senior }}" name="senior">
                                <span style="color: red">
                                        @error('senior')
                                            {{ $message }}
                                        @enderror
                                </span><br>
                            </div>
                            <div class="f-box">
                                <label for="">Gradute year</label>
                                <input type="text" placeholder="" value="{{ $education->YearSenior }}" name="YearSenior">
                                <span style="color: red">
                                        @error('YearSenior')
                                            {{ $message }}
                                        @enderror
                                </span><br>
                            </div>
                        </div>

                        <button style="width:100%;" type="submit" class="mt-4 btn btn-success btn-sm">Save information</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>