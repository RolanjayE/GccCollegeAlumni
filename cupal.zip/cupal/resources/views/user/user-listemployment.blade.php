<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employment</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">

    <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

    <x-globalHeader />
    <link rel="stylesheet" href="{{ asset('global/global.css') }}">
    <link rel="stylesheet" href="{{ asset('user/user-list-graduate.css') }}">
</head>
<body>
    

    <div class="bg">

    </div>

    <div class="list-container">
        <div class="wrapper">
            <div class="list-header">
                <a class="btn btn-success btn-sm" href="{{ route('user-home') }}">Home</a>
                <a style="float: right;" class="btn btn-primary btn-sm" href="{{ route('user-employment') }}">Add Jobs</a>
            </div>
            <p class="p6">My Jobs</p>
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                    <table id="example" class="table table-striped mt-2" style="width:100%">
                        <thead>
                            <tr>
                                <th>Company Name</th>
                                <th>Job Title</th>
                                <th>Position</th>
                                <th>Operation</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($jobs as $job)
                                <tr>
                                    <td>{{ $job->company }}</td>
                                    <td>{{ $job->title }}</td>
                                    <td>{{ $job->position }}</td>
                                    <td>
                                        <a style="float: right;" class="btn btn-primary btn-sm" href="{{ route('user-updateemployment', ['answer' => $job->id ]) }}">Update</a>
                                        <a style="float: right; margin-right: 5px;" class="btn btn-danger btn-sm" href="{{ route('user-deleteUpdateemployment', ['answer' => $job->id ]) }}">delete</a>
                                   </td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Company Name</th>
                                <th>Job Title</th>
                                <th>Position</th>
                                <th>Operation</th>
                            </tr>
                        </tfoot>
                    </table>


        </div>
    </div>

    <script>
        new DataTable('#example');
    </script>

</body>
</html>